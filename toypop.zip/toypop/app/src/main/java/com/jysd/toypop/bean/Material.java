package com.jysd.toypop.bean;

public class Material {
	public String email;
	public String title;
	public String des;
}
