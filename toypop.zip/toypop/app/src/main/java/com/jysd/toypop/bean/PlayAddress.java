package com.jysd.toypop.bean;

import java.util.List;

/**
 * Created by sysadminl on 2016/1/15.
 */
public class PlayAddress {
    public List<V> V;
}
