package com.jysd.toypop.view.impl;

/**
 * Created by sysadminl on 2015/12/9.
 */
public interface IBaseView {
}
