package com.jysd.toypop.bean;

/**
 * Created by sysadminl on 2016/1/15.
 */
public class V {
    public String U;
}
