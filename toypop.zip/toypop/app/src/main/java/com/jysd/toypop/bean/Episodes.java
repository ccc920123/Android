package com.jysd.toypop.bean;

import java.util.List;

/**
 * Created by sysadminl on 2016/1/5.
 */
public class Episodes {
    public List<Episode> episodes;
}
