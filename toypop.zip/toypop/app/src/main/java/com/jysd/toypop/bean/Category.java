package com.jysd.toypop.bean;

import java.io.Serializable;

public class Category implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1734593154041509860L;
	public String count;
	public String id;
	public String name;
	public String icon;
}
