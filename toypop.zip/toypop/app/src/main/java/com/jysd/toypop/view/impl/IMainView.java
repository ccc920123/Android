package com.jysd.toypop.view.impl;


import com.jysd.toypop.bean.User;

/**
 * Created by sysadminl on 2016/1/22.
 */
public interface IMainView extends IBaseView {
    public void setUserInfo(User user);
}
