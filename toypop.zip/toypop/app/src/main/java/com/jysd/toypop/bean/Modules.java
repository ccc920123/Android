/**
  * Copyright 2015 aTool.org 
  */
package com.jysd.toypop.bean;
/**
 * Auto-generated: 2015-12-21 12:51:35
 *
 * @author aTool.org (i@aTool.org)
 * @website http://www.atool.org/json2javabean.php
 */
public class Modules {

    private int modulesId;
    private String modulesName;
    private int sort;
    private String flag;
    private String icon;
    private String modulsCover;
    private String modulesColor;

}