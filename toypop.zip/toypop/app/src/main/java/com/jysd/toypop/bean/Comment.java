package com.jysd.toypop.bean;


public class Comment{
	public String commentId;
	public String content;
	public String flag;
	public String published;
	public User user;
}
