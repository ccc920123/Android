package com.jysd.toypop.model;


import com.jysd.toypop.bean.Material;
import com.jysd.toypop.model.impl.IProvideModel;

/**
 * Created by sysadminl on 2015/12/9.
 */
public class ProvideModel implements IProvideModel {

    @Override
    public void upProvide(Material material) {

    }
}