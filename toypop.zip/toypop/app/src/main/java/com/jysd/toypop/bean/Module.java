package com.jysd.toypop.bean;

import java.io.Serializable;

public class Module implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7906082295649320247L;

	public int modulesId;
	public String modulesName;
	public int sort;
	public String flag;
	public String icon;
}
