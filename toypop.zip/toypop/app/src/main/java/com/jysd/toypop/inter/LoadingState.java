package com.jysd.toypop.inter;

/**
 * Created by sysadminl on 2016/1/21.
 */
public enum LoadingState {
    STATE_LOADING,
    STATE_EMPTY,
    STATE_NO_NET,
    STATE_ERROR;
}