package com.jysd.toypop.view.impl;

/**
 * Created by sysadminl on 2016/1/25.
 */
public interface ISettingView extends IBaseView{

    public void feedback(boolean isSuccess);
}
