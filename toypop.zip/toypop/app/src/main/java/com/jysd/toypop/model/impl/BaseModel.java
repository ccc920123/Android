package com.jysd.toypop.model.impl;

/**
 * Created by sysadminl on 2015/12/9.
 */
public interface BaseModel {
}
