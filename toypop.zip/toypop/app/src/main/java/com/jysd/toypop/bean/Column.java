/**
  * Copyright 2016 aTool.org 
  */
package com.jysd.toypop.bean;
import java.util.List;

/**
 * Auto-generated: 2016-01-02 1:48:3
 *
 * @author aTool.org (i@aTool.org)
 * @website http://www.atool.org/json2javabean.php
 */
public class Column {

    public int id;
    public String name;
    public List<Series> series;

}