package com.jysd.toypop.bean;

/**
 * Created by sysadminl on 2015/12/26.
 */
public class PlayUrl {

    public String player;

}