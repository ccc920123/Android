package com.jysd.toypop.inter;

/**
 * Created by sysadminl on 2016/1/21.
 */
public interface OnRetryListener {
    void onRetry();
}
