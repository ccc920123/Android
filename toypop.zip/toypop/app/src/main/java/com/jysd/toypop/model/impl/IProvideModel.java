package com.jysd.toypop.model.impl;


import com.jysd.toypop.bean.Material;

/**
 * Created by sysadminl on 2015/12/9.
 */
public interface IProvideModel extends BaseModel {
    void upProvide(Material material);
}
