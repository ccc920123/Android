/**
  * Copyright 2015 aTool.org 
  */
package com.jysd.toypop.bean;
import java.util.List;

/**
 * Auto-generated: 2015-12-21 12:51:35
 *
 * @author aTool.org (i@aTool.org)
 * @website http://www.atool.org/json2javabean.php
 */
public class Beaty {

    public List<Resources> resources;

}