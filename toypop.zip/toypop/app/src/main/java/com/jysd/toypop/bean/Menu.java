package com.jysd.toypop.bean;

import java.io.Serializable;

public class Menu implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1615706284945560694L;
	public String name;
	public String icon;
	public int id;
}
