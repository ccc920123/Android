package com.jysd.toypop.bean;


import com.umeng.socialize.bean.SHARE_MEDIA;

/**
 * Created by sysadminl on 2016/1/20.
 */
public class Share {
    public int resPic;

    public String resStr;
    public SHARE_MEDIA share_media;
}
