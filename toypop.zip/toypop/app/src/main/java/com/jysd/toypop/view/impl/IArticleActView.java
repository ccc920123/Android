package com.jysd.toypop.view.impl;

/**
 * Created by sysadminl on 2016/1/18.
 */
public interface IArticleActView extends IBaseView {
    void setContent(String content);

}
