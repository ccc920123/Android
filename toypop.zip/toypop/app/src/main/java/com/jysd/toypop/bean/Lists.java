/**
 * Copyright 2015 aTool.org
 */
package com.jysd.toypop.bean;

import java.util.List;

/**
 * Auto-generated: 2015-12-18 12:34:41
 *
 * @author aTool.org (i@aTool.org)
 * @website http://www.atool.org/json2javabean.php
 */
public class Lists {
    public List<Anime> anime;
}