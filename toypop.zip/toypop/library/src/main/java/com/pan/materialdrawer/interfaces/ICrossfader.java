package com.pan.materialdrawer.interfaces;

/**
 * Created by mikepenz on 18.07.15.
 */
public interface ICrossfader {
    void crossfade();

    boolean isCrossfaded();
}
